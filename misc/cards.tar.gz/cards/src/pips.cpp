#include "pips.h"

pips::pips()
{
    //ctor
}
