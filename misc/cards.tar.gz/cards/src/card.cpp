#include "card.h"

card::card()
{
    //ctor
}
