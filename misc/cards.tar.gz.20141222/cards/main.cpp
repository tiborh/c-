#include <iostream>
#include "include/deck.h"
#include "include/card.h"

using namespace std;

int main()
{
    deck a_deck;
    cout << "\nFresh deck:\n";
    a_deck.init_deck();
    a_deck.pr_deck();

    cout << "\nShuffled deck:\n";
    a_deck.shuffle();
    a_deck.pr_deck();

    cout << "\nDeal 5 cards:\n";
    hand a_hand(5);
    a_deck.deal(5,a_hand);
    a_deck.pr_deck();
    cout << "And the hand:\n";
    a_hand.show_hand();

    return 0;
}
