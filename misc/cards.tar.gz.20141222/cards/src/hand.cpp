#include "hand.h"
using namespace std;

hand::hand(int hand_size)
{
    max_hs = hand_size;
}

unsigned int hand::add_card(card c)
{
    if (h.size() <= max_hs)
        h.push_back(c);
    else
        cout << "Hand is full.\n";

    return h.size();
}

void hand::show_hand()
{
    vector<card>::iterator hi;
    //vector<card>::iterator first = h.begin();
    //vector<card>::iterator last = h.end();
    int i;
    for (i = 1, hi = h.begin(); hi != h.end(); hi++, i++)
    {
        cout << "Card" << i << ": ";
        (*hi).pr_card();
        cout << endl;
    }

}
