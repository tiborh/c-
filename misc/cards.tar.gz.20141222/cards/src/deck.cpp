#include <cstdlib>
#include <ctime>
#include "deck.h"
#include "hand.h"

void deck::init_deck()
{
    topcard = 0;
    for (int i = 0; i < CARDS_IN_SUIT * NUM_OF_SUITS; i++)
        d[i].assign(i);
}

void deck::swap_cards(card& c1, card& c2)
{
    card t;
    t = c1;
    c1 = c2;
    c2 = t;
}

void deck::shuffle()
{
    srand(time(NULL));
    for (int i = 0; i < CARDS_IN_SUIT * NUM_OF_SUITS; i++)
        swap_cards(d[i],d[rand() % (CARDS_IN_SUIT * NUM_OF_SUITS)]);
}

void deck::deal(int num, hand& ahand)
{
    int i = topcard;
    for(; i < topcard + num && i < CARDS_IN_SUIT * NUM_OF_SUITS; i++)
        ahand.add_card(d[i]);

    topcard = i;
    if (topcard == CARDS_IN_SUIT * NUM_OF_SUITS - 1)
        std::cout << "No cards in deck.\n";
}

void deck::pr_deck()
{
    for (int i = topcard; i < CARDS_IN_SUIT * NUM_OF_SUITS; i++)
    {
        if (i % CARDS_IN_SUIT == 0) // determines number of cards in a row
            std::cout << std::endl;
        d[i].pr_card();
    }
    std::cout << std::endl;
}
