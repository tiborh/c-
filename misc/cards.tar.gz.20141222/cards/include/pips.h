#ifndef PIPS_H
#define PIPS_H
#include <iostream>
#include "../cards.h"

class pips
{
    public:
        void assign(int n) { p = n % CARDS_IN_SUIT + 1; }
        void print() const { std::cout << pips_symbol[p]; }
    private:
        int p;
};

#endif // PIPS_H
