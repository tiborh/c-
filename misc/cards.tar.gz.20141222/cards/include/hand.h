#ifndef HAND_H
#define HAND_H
#include <vector>
#include "card.h"

class hand
{
    public:
        hand(int);
        unsigned int add_card(card);
        void show_hand();
    private:
        unsigned int max_hs;
        std::vector<card> h;
};

#endif // HAND_H
