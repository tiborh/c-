#ifndef DECK_H
#define DECK_H
#include <iostream>
#include "../cards.h"
#include "card.h"
#include "hand.h"

class deck
{
    public:
        void init_deck();
        void shuffle();
        void deal(int, hand&);
        void pr_deck();
        int cards_left() { return CARDS_IN_SUIT * NUM_OF_SUITS - topcard - 1; }
    private:
        int topcard;
        void swap_cards(card&,card&);
        card d[NUM_OF_CARDS];
};

#endif // DECK_H
