#ifndef CARD_H
#define CARD_H
#include <iostream>
#include "../cards.h"
#include "pips.h"

class card
{
    public:
        suit s;
        pips p;
        void assign(int n)
        {
            cd = n;
            s = suit(n/CARDS_IN_SUIT);
            p.assign(n);
        }
        void pr_card()
        {
            p.print();
            std::cout << suit_symbol[s] << " ";
        }
    private:
        int cd; // a cd is from 0 to 51
};

#endif // CARD_H
