#include <iostream>
#include <iomanip> // for draw_square
#include <cmath> // for draw_square
#include <cstring> // for strlen
#include <fstream> // for main
//#include <exception>
//#include <cstdlib> // for exit codes
#include "file_checks.h"

using namespace std;

void draw_squre(int n,fstream& fh)
{
    int counter = 0;
    int rowstart = 0;
    for (int i = 0; i < n; ++i)
    {
        counter = rowstart;
        for (int j = 0; j < n; ++j)
        {
            fh << setw(static_cast<int>(log10(n)+2)) << counter;
            if (j < n/2)
                counter++;
            else if (j >= n/2)
                counter--;
        }
        fh << endl;
        if (i < n/2)
            rowstart++;
        else if (i >= n/2)
            rowstart--;
    }
}

bool open_file(fstream& fh, const char* fn, const char* fm)
{
  ios::openmode fmode;
  int fmode_int = 0;

  for(unsigned int i = 0; i < strlen(fm); i++)
  switch(fm[i])
    {
    case 'r': fmode_int += ios::in; break;
    case 'w': fmode_int += ios::out; break;
    case 'a': fmode_int += ios::app; break; // use it with write
    case 't': fmode_int += ios::trunc; break; // use it with write
    case 'e': fmode_int += ios::ate; break; // use it with r or w
    case 'b': fmode_int += ios::binary; break; // use it with r or w
    default:
      cerr << "Unknown fileopen mode:" << fm << "Exiting...\n";
      return false;
    }

  //cout << ">>>fopen mode (int): " << fmode_int << endl;
  //to do: valid fmode combinations should be checked!
  fmode = static_cast<ios::openmode>(fmode_int);
  fh.open(fn,fmode);
  if (fh.is_open())
    return true;
  else
    return false;
}

int get_file_size(const char* fn)
{
    fstream fh;
    open_file(fh,fn,"re");
    int filesize = static_cast<int>(fh.tellg()) + 1;
    fh.close();

    return filesize;
}

//to check open/access errors
bool open_file(ofstream& fh, const char* fn)
{
    //fh.exceptions ( ofstream::failbit | ofstream::badbit );

    //try {
    fh.open(fn); // default is ios::out, others: ios::app, ios::binary, ios::trunc
    //} catch (ofstream::failure e) {
    //    cout << "failed to open: " << e.what() << endl;
    //}

    if (!fh.is_open())
    {
        bool file_exists = f_exists(fn);
        bool file_is_good = f_is_good(fn);
        cerr << "Unable to open file '" << fn << "'\n";
        clog << "Basic file information:\n";
        clog << "\tFile is " << (file_is_good ? "" : "not ") << "good.\n";
        if (!file_is_good)
        {
            clog << "\t\tFile " << (file_exists ? "exists" : "does not exist") << ".\n";
            if (file_exists)
            {
                clog << "\t\tFile read access is " << (f_read_access(fn) ? "" : "not ") << "good.\n";
                clog << "\t\tFile write access is " << (f_write_access(fn) ? "" : "not ") << "good.\n";
                clog << "\t\tFile execute access is " << (f_execute_access(fn) ? "" : "not ") << "good.\n";
                clog << "Further file statistics:\n";
                f_stat(fn);
            } else
            {
                cerr << "Check if you have write access to target directory.\n";
                char cCurrentPath[FILENAME_MAX];
                getcwd(cCurrentPath, sizeof(cCurrentPath));
                clog << "\tWrite access to " << cCurrentPath << " is " << (f_write_access(cCurrentPath) ? "" : "not ") << "good.\n";
            }
        } else
            cerr << "No useful data has been found about the file.\n";
        return false;
    }
    return true;
}

char* get_file_content(const char* fn)
{
    fstream fh;
    int fs = get_file_size(fn);
    if (fs > 0)
    {
        open_file(fh,fn,"r");
        if (fh.is_open())
        {
            char* filecontent = new char[fs+1];
            char read_char = 0;
            for (int i = 0; i < fs; i++)
            {
                fh.read(&read_char,sizeof(char));
                filecontent[i] = read_char;
            }
            filecontent[fs] = '\0';
            return filecontent;
            fh.close();
        } else
            return NULL;
    }
    return NULL;
}

char* get_file_content_backwards(const char* fn)
{
    fstream fh;
    int fs = get_file_size(fn);
    if (fs > 0)
    {
        open_file(fh,fn,"r");
        if (fh.is_open())
        {
            char* filecontent = new char[fs+1];
            char read_char = 0;
            for (int i = fs; i > -1; i--) //while(fh) is also possible
            {
                fh.get(read_char);
                filecontent[i] = read_char;
            }
            filecontent[fs] = '\0';
            return filecontent;
            fh.close();
        } else
            return NULL;
    }
    return NULL;
}

int main()
{
    const char* fn = "sample.txt";
    fstream fh;
    if (open_file(fh,fn,"w"))
    {
        draw_squre(51,fh);
        fh.close();
    }

    fn = "wandrers_nachtlied.txt";
    if (open_file(fh,fn,"r"))
    {
        char *fc = get_file_content(fn);
        cout << "The file content:\n";
        cout << fc << endl;
        fh.close();
    }

    if (open_file(fh,fn,"r"))
    {
        char *fc = get_file_content_backwards(fn);
        cout << "The file content backwards:\n";
        cout << fc << endl;
        fh.close();
    }


    return 0;
}
